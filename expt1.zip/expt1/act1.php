<!DOCTYPE HTML> 
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Experiment 1 - Activity 1</title>
    </head>
    <body>
        <?php
        echo "Hello Luces!!!"
        ?>
    </body>
</html>
