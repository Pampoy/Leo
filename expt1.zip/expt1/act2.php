<!DOCTYPE HTML> 
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Activity 2</title>
    </head>
    <body>
        <?php
        echo 'Hello \'95 is Luces!';
        echo " Welcome to \"COGNATE3\".";
        ?>
    </body>
</html>
